import React from 'react'
import { connect } from 'react-redux'
import { addTodo } from '../actions/action.js'

let AddTodo = ({ dispatch }) => {
  let input

  return (
    <div>
      <form
        onSubmit={e => {
          e.preventDefault()
          if (!input.value.trim()) {
            return
          }
          dispatch(addTodo(input.value))
          input.value = ''
        }}
      >
        <input className="calcInput" placeholder="运算数"/>

        <select className="calcInput operator">
          <option value="+"> + </option>
          <option value="-"> － </option>
          <option value="*"> × </option>
          <option value="\/"> ÷ </option>
        </select>

        <input className="calcInput" placeholder="运算数"/>

        <button type="submit" className="calcEq">
          等于
        </button>
      </form>
    </div>
  )
}
AddTodo = connect()(AddTodo)

export default AddTodo