import React from 'react'
import FilterLink from '../containers/FilterLink'

const Result = () => (
  <div>
        <p>
        Show:
          {' '}
          <FilterLink filter="SHOW_ALL">
            All
          </FilterLink>
          {', '}
          <FilterLink filter="SHOW_ACTIVE">
            Active
          </FilterLink>
          {', '}
          <FilterLink filter="SHOW_COMPLETED">
            Completed
          </FilterLink>
        </p>
      <div className="showResult">
          <p>结果：</p>
      </div>
  </div>
)

export default Result