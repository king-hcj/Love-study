import React from 'react'
import Header from './Header'
import Result from './Result'
import AddTodo from '../containers/AddTodo'
import VisibleTodoList from '../containers/VisibleTodoList'
import '../Calc.css';

const Calc = () => (
  <div className="Calc">
  	<Header />   
    <AddTodo />
    <VisibleTodoList />
    <Result />
  </div>
)

export default Calc