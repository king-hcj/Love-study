import React from 'react'

//计算器头部及tab部分
const Header = () => (
  <div>
    <h1>Redux Calc 1.0</h1>
    <ul>
      <li>
          进行计算
      </li>
      <li>
          结果翻转
      </li>
    </ul>
    <hr/>
  </div>
)

export default Header