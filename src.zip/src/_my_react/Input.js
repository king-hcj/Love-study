import React, { Component } from 'react';
import './Calc.css';

// 输入、输出等主要操作
class Input extends Component { 
  constructor () {
    super()
    this.state = { //运算数、操作符、计算结果
      data1: '',
      data2: '',
      operator:'+',
      result:'0',
      isZero:"点击等号完成计算！",
      display:"none"  //提示内容显示的控制
    }
  }

    FocusHandle (event) {    //聚焦时，选中内容
    event.target.placeholder="";
    event.target.select();
    this.setState({
        display:"none"
      })
    }
    BlurHandle(event){
      event.target.placeholder="运算数";
    }

   firstChangeHandle (event) {
    if(event.target.value==="")return;
    this.setState({
      data1: parseFloat(event.target.value),
    })
    if(this.state.data2){
      this.setState({
        isZero: "点击等号，完成计算！",
        display:"block"
      })
    }
  }

  secondChangeHandle (event) {
    if(event.target.value==="")return;
    this.setState({
      data2: parseFloat(event.target.value),
    })
    if(this.state.data1){
      this.setState({
        isZero: "点击等号，完成计算！",
        display:"block"
      })
    }
  }
  operatorChangeHandle (event) {
    this.setState({
      operator: event.target.value
    })
    if(this.state.data1 && this.state.data2){
      this.setState({
        isZero: "点击等号，完成计算！",
        display:"block"
      })
    }
  }


  handleClick(){  //等号点击响应函数
    let tmp;
    if (this.state.operator==="+") {
      tmp=this.state.data1 + this.state.data2;
    }else if(this.state.operator==="-"){
      tmp=this.state.data1 - this.state.data2;
    }else if(this.state.operator==="*"){
      tmp=this.state.data1 * this.state.data2;
    }else{
      if(this.state.data2===0){
        this.setState({
            result: 0,
            isZero: "对不起，0不能做除数！",
          })
        this.props.changeReverseText("您还没有进行计算，无法翻转！!")
        return;
      }
      tmp=this.state.data1 / this.state.data2;
    }
    this.setState({
      result: tmp
    })

    // 处理翻转结果
    let Lstr=tmp.toString().split('')[0]; //结果最左边字符判断用
    if(Lstr==="-"){
      tmp=tmp.toString().split('').slice(1).reverse().join('');
      tmp="-" + tmp
    }else{
      tmp=tmp.toString().split('').reverse().join('');
    }
    this.props.changeReverseText("翻转结果："+tmp)
  }


  render () {
    return (
      <div>
        <input type="number" className="calcInput" placeholder="运算数"
        value={this.state.data1} onFocus={event=>this.FocusHandle(event)}
        onBlur={event=>this.BlurHandle(event)} onChange={event=>this.firstChangeHandle(event)}/>

        <select className="calcInput operator" value={this.state.operator} 
        onChange={event=>this.operatorChangeHandle(event)}>
          <option value="+"> + </option>
          <option value="-"> － </option>
          <option value="*"> × </option>
          <option value="\/"> ÷ </option>
        </select>

        <input type="number" className="calcInput" placeholder="运算数"
        value={this.state.data2} onFocus={event=>this.FocusHandle(event)} 
        onBlur={event=>this.BlurHandle(event)} onChange={event=>this.secondChangeHandle(event)}/>

        <button type="button" className="calcInput operator" 
        onClick={event=>this.handleClick(event)}> = </button>
        
        <hr/>
        <span>提示：</span><p id="imply" style={{display: this.state.display}}>{this.state.isZero}</p>
        

        <div className="showResult">
          <p>结果：</p>
          <textarea value={this.state.result} disabled={true} />
        </div>
      </div>
    )
  }
}

export default Input;