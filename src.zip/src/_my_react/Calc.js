import React, { Component } from 'react';
import Input from './Input.js';
import Title from './Title.js';
import './Calc.css';

// Calc组件start
class Calc extends Component {
  constructor(props) {
        super(props);
        this.state = {
            tabs:[
                {tabName:"计算器",id:1},
                {tabName:"翻转结果",id:2},
            ],
            currentIndex:1,
            showReverseText:"您还没有进行计算，无法翻转!!！"   //翻转部分提示内容
        };
    }    

    tabChoiced=(id)=>{
        //tab切换
        this.setState({
            currentIndex:id
        });
    }

    changeReverseText(showReverseText){
      this.setState({
            showReverseText
        });
    }

  render () {
     let _this=this;
        let isBox1Show=this.state.currentIndex===1 ? 'inline-block' : 'none';
        let isBox2Show=this.state.currentIndex===2 ? 'inline-block' : 'none';
          let tabList= this.state.tabs.map(function(res,index) {
              // 遍历标签页，如果标签的id等于tabid，那么该标签就加多一个active的className
            let tabStyle=res.id===this.state.currentIndex ? 'subCtrl active' : 'subCtrl';

            return <li key={index} onClick={this.tabChoiced.bind(_this,res.id)}
             className={tabStyle}>{res.tabName}</li>
        }.bind(_this));

    return (
        <div className="Calc">
          <Title />

          <div className="listWrap">
                <ul className="Tab">
                    {tabList}
                </ul>
                <div className="newsList">
                    <div style={{"display":isBox1Show}} >
                        {<Input changeReverseText={showReverseText => this.changeReverseText(showReverseText)}/>} 
                    </div>
                    <div style={{"display":isBox2Show}} className="showReverse">
                      <p>{this.state.showReverseText}</p>
                    </div>
                </div>
          </div>

        </div>
    )
  }
}
//Calc组件end

export default Calc;
