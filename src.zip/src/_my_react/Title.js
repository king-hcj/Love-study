import React, { Component } from 'react';
import './Calc.css';

//Title组件，定义顶部标题
class Title extends Component {
  render () {
    return (
      <div>
          <h1>React Calc 1.0</h1>
          <hr/>
      </div>
    )
  }
}

export default Title;