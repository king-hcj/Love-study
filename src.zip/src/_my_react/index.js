import React from 'react';
import ReactDOM from 'react-dom';
import './_my_react/index.css';
import Calc from './_my_react/Calc';
import registerServiceWorker from './_my_react/registerServiceWorker';

ReactDOM.render(
	<Calc />,
	 document.getElementById('root')
	 );
registerServiceWorker();
