const appState = {
  data: {
    data1: 0,
    data2: 0,
    operator：
    result:0
  },
  tabs: {
   tabName:"计算器",id:1,
   tabName:"翻转结果",id:2,
  }
  currentIndex:1,
  showReverseText:"您还没有进行计算，无法翻转!!！"
  style:"display"
  placeholder:"运算数"
}


action： change;submit；click；keypress