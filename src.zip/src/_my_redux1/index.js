import React from 'react'
import { render } from 'react-dom'
import { Provider } from 'react-redux'
import { createStore } from 'redux'
import todoApp from './_my_redux1/reducers/todoApp'
import Calc from './_my_redux1/components/Calc'

let store = createStore(todoApp)

render(
  <Provider store={store}>
    <Calc />
  </Provider>,
  document.getElementById('root')
)